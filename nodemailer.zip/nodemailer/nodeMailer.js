const nodemailer = require('nodemailer')

const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    secure: false,
    auth: {
        user: 'jett.shanahan89@ethereal.email',
        pass: 'V2KFC8PgfgWVUWGDTa'
        }
    },
    {
        from: 'Mailer test <jett.shanahan89@ethereal.email>',
    }
)

const mailer = massage => {
    transporter.sendMail(massage, (err,info) => {
        if(err) return console.log(err)
        console.log('Email sent: '. info)
    })
}

module.exports = mailer